 <div class="span2"> 
	 <ul class="nav nav-list" id="cloudManageMenu">
		  <li class="nav-header">서버관리</li>
		  <li id="serverinfoMenu"><a href="#">서버상세보기</a></li>
		  <li id="diskinfoMenu"><a href="#">Disk상세보기</a></li>	 
	</ul> 
 </div> 
