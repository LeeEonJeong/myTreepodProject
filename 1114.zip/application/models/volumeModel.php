<?php

class VolumeModel extends CI_Model {
	public function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' );
	}
	
	public function getlistVolumes() { // 전체 VM들 가져오기
		$cmdArr = array (
				"command" => "listVolumes",
				"apikey" => $_SESSION ['apikey'] 
		);
		
		$volumes = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $volumes;
	}
	
	public function getVolumesByZoneid($zoneid){
		$result = $this->getlistVolumes();
		if($result == null){
			return;
		}
		$volumes = $result['volume'];
		$count = $result['count'];
		
		$resultArray = array();
		
		for($i=0; $i<$count; $i++){
			if($count == 1){
				$volume = $volumes;
			}else{
				$volume = $volumes[$i];
			}
			
			if($volume['zoneid'] == $zoneid){
				array_push($resultArray, $volume);
			}
		}
		
		$temp['count'] = count($resultArray);
		
		if(count($resultArray) == 1){
			$temp['volume'] = $resultArray[0];
		}else{
			$temp['volume']  = $resultArray;
		}
		return $temp;
	}
	
	public function searchVolume($volumeid){
		$cmdArr = array (
				"command" => "listVolumes",
				"id" => $volumeid,
				"apikey" => $_SESSION ['apikey']
		);
		
		$volume = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $volume;
	}
	
	public function getAddVolumeCount(){
		$result = $this->getlistVolumes();
		
		$count = $result['count'];
		$volumes = $result['volume'];
		$addVolumeCount = 0;
		
		for($i=0; $i<$count; $i++){
			if($count==1){
				$volume = $volumes;
			}else{
				$volume = $volumes[$i];
			} 
			$typetext = $volume['type'];
			 
			if($typetext == 'DATADISK'){
				if(strpos($volume['diskofferingdisplaytext'], 'Additional') !== false) {
					$addVolumeCount++;
				}
			}
		}
		return $addVolumeCount;
	}
	
	public function getVolumes($virtualmachineid){
		$cmdArr = array (
				"command" => "listVolumes",
				"virtualmachineid" => $virtualmachineid,
				"apikey" => $_SESSION ['apikey'] 
		);
		
		$volumes = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $volumes;
	}
	
	//쓰지말자(general error발생, zoneid로 찾을경우)
	function getVolumesByCondition($condition, $value){
		$cmdArr = array (
				"command" => "listVolumes",
				$condition => $value,
				"apikey" => $_SESSION ['apikey']
		);
	
		$volumes = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $volumes;
	}
	
	public function attachVolume($id, $virtualmachineid){
		$cmdArr = array (
				"command" => "attachVolume",
				"id" => $id,
				"virtualmachineid" => $virtualmachineid,
				"apikey" => $_SESSION ['apikey']
		);
		
		$volumes = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $volumes;
	}
	
	public function detachVolume($id){
		$cmdArr = array (
				"command" => "detachVolume",
				"id" => $id,
				"apikey" => $_SESSION ['apikey']
		);
	
		$volumes = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $volumes;
	}
	
	public function deleteVolume($id){
		$cmdArr = array (
				"command" => "deleteVolume",
				"id" => $id,
				"apikey" => $_SESSION ['apikey']
		);
	
		$volumes = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $volumes;
	}
	 
}