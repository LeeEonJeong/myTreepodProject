<?php
class OrderCloudModel extends CI_Model {
	public function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' ); 
	}
	
	public function checkVirtualMachineName($checkname){
		$cmdArr = array (
				"command" => "checkVirtualMachineName",
				"display_name" => $checkname,
				"apikey" => $_SESSION ['apikey']
		);
			
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		return $result;
	}
	
	public function orderVM(){
		$cmdArr = array (
				"command" => "deployVirtualMachine",
				"displayname" => $_POST['displayname'],
				"name" => $_POST['name'],
				"serviceofferingid" => $_POST['serviceofferingid'],
				"templateid" => $_POST['templateid'],
				"zoneid" => $_POST['zoneid'],
				"usageplantype" => $_POST['usageplantype'],
				"apikey" => $_SESSION ['apikey']
		);
		
		if($_POST['diskofferingid'] != ''){
			$cmdArr['diskofferingid'] = $_POST['diskofferingid'];
		}
		
		$result = $this->callApiModel->callCommand(CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );

		return $result;  //file_get_contents에서 실패시 false return
	}
	

	public function getPackagesByZoneid($zoneid){
		$availableProductTypes = $this->getlistAvailableProductTypesByZoneid($zoneid);
		$count = $availableProductTypes['count'];
		$productTypes = $availableProductTypes['producttypes'];
		 
		$index=0;
		
		if($count==0){
			return null;
		}
		$packages = $this->getUniqueValueList($productTypes, 'product');
		
		return $packages;			
	}
	
	private function getlistAvailableProductTypesByZoneid($zoneid){
		$cmdArr = array (
				"command" => "listAvailableProductTypes",
				"zoneid" => $zoneid,
				"apikey" => $_SESSION ['apikey']
		);
			
		$listAvailableProductTypes = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $listAvailableProductTypes;
	}
	
	public function getOSlist($zoneid, $package){
		$productsArray = $this->getProductsByZoneidAndPackage($zoneid, $package);
		$oslist = $this->getUniqueValueForIdAndDesc($productsArray, 'template');
		return $oslist;
	}
	
	public function getServiceOfferinglist($zoneid, $package, $osid){
		$productsArray = $this->getProductsByZoneidAndPackage($zoneid, $package);
		$osproducts = $this->getProducts($productsArray, 'templateid', $osid);
		
		$serviceofferinglist = $this->getUniqueValueForIdAndDesc($osproducts, 'serviceoffering');
		
		return $serviceofferinglist;
	}
	
	public function getDiskOfferinglist($zoneid, $package, $osid, $serviceid){
		$productsArray = $this->getProductsByZoneidAndPackage($zoneid, $package);
		$osproducts = $this->getProducts($productsArray, 'templateid', $osid);
		$serviceproducts = $this->getProducts($osproducts, 'serviceofferingid', $serviceid);
		$diskofferinglist = $this->getUniqueValueForIdAndDesc($serviceproducts, 'diskoffering');
		
		return $diskofferinglist;
	}
	
	private function getUniqueValueList($array,$condition){ //모든값들이 정렬되었다는 가정하에(Standard, Hight Memory, SSD)
		$resultasrray = array();
	
		$old = '';
		foreach($array as $key=>$value){
			$new = $value[$condition];
			if($old != $new && $new != null){
				array_push($resultasrray, $new);
				$old = $new;
			}
		}	
		return $resultasrray;
	}
	
	private function getUniqueValueForIdAndDesc($array,$condition){ //condition : serviceoffering,template,diskoffering
		if(!is_array($array)){
			return;
		}
		
		$resultarray = array();
	 
		if(count($array) < 1){
		}else if(count($array) == 1){
			$temparray[$condition.'id'] = $value[$condition.'id'];
			$temparray[$condition.'desc'] = $value[$condition.'desc'];
		}else{
			foreach($array as $key=>$value){
				$new = $value[$condition.'desc'];
				if($new == null || $this->isExist($resultarray, $new)){
				}else{
					if(isset($value[$condition.'id'])){ //diskoffering때문에 rootonly는 id값없음
						$temparray[$condition.'id'] = $value[$condition.'id'];
					}else{
						$temparray[$condition.'id'] ='';
					}
					$temparray[$condition.'desc'] = $new;
					array_push($resultarray, $temparray);
				}
			}
		}
		return $resultarray;
	}
	
	private function isExist($array, $value){
		foreach($array as $arraykey => $arrayvalue){
			foreach($arrayvalue as $conditionkey => $conditionvalue){
				if($conditionvalue == $value)
					return true;
			}
		}
		return false;
	}
	
	private function getProductsByZoneidAndPackage($zoneid, $package){
		$result = $this->getlistAvailableProductTypesByZoneid($zoneid);
		return $this->getProducts($result['producttypes'], 'product', $package);
	}
	
	//productTypes 배열안에 있는 prodcutType중에 condition이 substring을 포함하는 것을 배열에 담아서 가져온다.
	private function getProducts($productTypes, $condition, $substring){
		if(!is_array($productTypes)){
			return;
		}
		
		$products = array();

		foreach($productTypes as $key=>$value){
			$product = $value;
			$ishas = strpos($product[$condition], $substring);
			
			if($ishas !== false){
				array_push($products, $product);
			}
		}
		return $products;
	}
	
	private function getAvailableProductTypes($zoneid, $condition, $value){
		$availableProductTypes = $this->getlistAvailableProductTypesByZoneid($zoneid);
		$count = $availableProductTypes['count'];
		 
		$productTypes = $availableProductTypes['producttypes'];
		$products = array();
		$index=0;
		
		for($i=0; $i<$count; $i++){
			$product = $productTypes[$i];
			 
			if($product[$condition] == $value){
				$products[$index++] = $product; 
			}
		}
		 
		return $products;
	}
}