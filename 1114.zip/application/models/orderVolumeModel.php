<?php

class OrderVolumeModel extends CI_Model {
	public function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' ); 
	} 
	
	public function orderVolume(){
		$cmdArr = array (
				"command" => "createVolume",
				"name" => $_POST['diskname'],
				"zoneid" => $_POST['zoneid'],
				"diskofferingid" => $_POST['diskofferingid'],
				"usageplantype" => $_POST['usageplantype'],
				"apikey" => $_SESSION ['apikey']
		);  
		$result = $this->callApiModel->callCommand(CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) ); 
		
		return $result;  
	}
 
}