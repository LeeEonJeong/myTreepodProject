<?php
 
class NasModel extends CI_Model {
	public function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' ); 
	} 
	 
	public function getlistVolumes(){
		$cmdArr = array (
				"command" => "listVolumes",
				"apikey" => $_SESSION ['apikey']
		);
	
		$result = $this->callApiModel->callCommand( CallApiModel::NASURI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		return $result;
	}
	
	public function getVolumes($condition, $value){
		$cmdArr = array (
				"command" => "listVolumes",
				$condition => $value,
				"apikey" => $_SESSION ['apikey']
		);
		$result = $this->callApiModel->callCommand( CallApiModel::NASURI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		return $result;
	}
	
	public function getVolumesByZoneid($zoneid){
		$result = $this->getVolumes('status', 'online');
		$resultArray = array();
	
		$count = $result['count']; //count가 0이면 resuelt['volume']은 안날라옴//array(2) { ["status"]=> string(7) "success" ["count"]=> string(1) "0" }
		if($count!=0){
			$volumes=$result['volume'];
		}
	
		for($i=0; $i<$count; $i++){
			if($count == 1){
				$volume = $result['response'];
			}else{
				$volume = $volumes[$i];
			}
				
			if($volume['zoneid'] == $zoneid){
				array_push($resultArray, $volume);
			}
		}
	
		$temp['count'] = count($resultArray);
		if(count($resultArray) == 0){
			$temp['response'] = null;
		}
		else if(count($resultArray) == 1){
			$temp['response'] = $resultArray[0];
		}else{
			$temp['response'] = $resultArray;
		}
	
		return $temp;
	}
	
	public function deleteVolume($volumeid) {
		$cmdArr = array (
				"command" => "deleteVolume",
				"id" => $volumeid,
				"apikey" => $_SESSION ['apikey']
		);
	
		$result = $this->callApiModel->callCommand( CallApiModel::NASURI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $result;
	}
	
	public function addNicToVirtualMachine($networkid,$virtualmachineid ){ //비동기
		$cmdArr = array (
				"command" => "addNicToVirtualMachine",
				"networkid" => $networkid,
				"virtualmachineid" => $virtualmachineid,
				"apikey" => $_SESSION ['apikey']
		);
		
		$jobid = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $jobid;
	}
	
	public function removeNicFromVirtualMachine($nicid,$virtualmachineid ){ //비동기
		$cmdArr = array (
				"command" => "removeNicFromVirtualMachine",
				"nicid" => $nicid,
				"virtualmachineid" => $virtualmachineid,
				"apikey" => $_SESSION ['apikey']
		);
		
		$jobid = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $jobid;
	}

	public function getRunningVolumeZones(){
		$runningVolumes = $this->getVolumes('status', 'online')['response'];
		$zoneids = array();
		
		foreach($runningVolumes as $volume){
			array_push($zoneids, $volume['zoneid']);
		}
		return $zoneids;
	} 
}