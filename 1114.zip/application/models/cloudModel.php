<?php

class CloudModel extends CI_Model {
	function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' );
 
	}
	
	public function getlistVMs() { // 전체 VM들 가져오기
		$cmdArr = array (
				"command" => "listVirtualMachines",
				"apikey" => $_SESSION ['apikey'] 
		);
		
		$vms = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $vms;
	}
	
	public function searchVM($vmid){ //조건들에 맞는 vm찾기
		return $this->getVMsByCondition('id', $vmid);
	}
	
	public function searchVMsByZoneid($zoneid){
		return $this->getVMsByCondition('zoneid', $zoneid);
	}
	
	public function getVMsForNAS(){
		$result = $this->getlistVMs();
		$vms = $result['virtualmachine'];
		$count = $result['count'];
		
		for($i=0; $i<$count; $i++){
			$vmForNAS=array();
			
			if($count == 1){
				$vm = $vms;
			}else{
				$vm = $vms[$i];
			}
			
			$vmForNAS['vmid'] = $vm['id'];
			$vmForNAS['useNas'] = $this->isUseNAS($vm);
				
			if($vmForNAS['useNas']){ //nas를 가지고 있으면 nicid를 넣어
				$vmForNAS['nicid'] = $this->getNasNetworkId($vm);
			}
				
			$vmForNAS['displayname'] = $vm['displayname'];
			$vmForNAS['zoneid'] = $vm['zoneid'];
			$vmForNAS['zonename'] = $vm['zonename'];
			$vmForNAS['templatedisplaytext'] = $vm['templatedisplaytext'];
			$vmForNAS['serviceofferingname'] = $vm['serviceofferingname'];
			$vmForNAS['state'] = $vm['state'];
			$VMsForNASs[] = $vmForNAS; //array_push($VMsForNASs, $vmForNAS);
		} 
		
		return $VMsForNASs;
	}
	
	private function isUseNAS($vm){
		$niccount = count($vm['nic']);
		
		if($niccount > 1){ //기본제공nic 하나 + NAS제공 nic
			$nics = $vm['nic'];
			 
			if(isset($nics['id'])){ //set되어있다면 기본제공해주는 nic하나인거지 
				return false;
			}
			 
			foreach($nics as $nic){
				if(strpos($nic['networkname'], "NAS") === 0)  // NAS로 시작 (0)
					return true;
			}	
		}
		return false;
	}
	
	private function getNasNetworkId($vm){
		$niccount = count($vm['nic']);
		
		if($niccount > 1){
			$nics = $vm['nic'];
		
			if(isset($nics['id'])){ //set되어있다면 하나인거지 nic가
				return false;
			} 
		
			foreach($nics as $nic){
				$name = $nic['networkname'];
// 				$temp = strpos($name, "NAS");
// 				echo $name.'<hr>'.$temp."<hr>";
				if(strpos($name, "NAS") === 0 ) 
					return $nic['id'];
			}
		}
		return false;
	}
	
	private function getVMsByCondition($condition, $value){
		$cmdArr = array (
				"command" => "listVirtualMachines",
				$condition => $value,
				"apikey" => $_SESSION ['apikey']
		);
		
		$vms = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $vms;
	} 
	  
	private function getVMs($listVMs, $condition, $value){ //해당 VM들 중에서 condition은 비교할 조건(존같은), value는 비교할 값
		$vmCount= $listVMs['count'];
		$resultIndex = 0;
		$result = array();
		
		if($vmCount == 1){
			if($listVMs['virtualmachine'][$condition] == $value ){
				return $listVMs['virtualmachine'];
			}
		}else{
			for($i=0; $i<$vmCount; $i++){
				$vm = $listVMs['virtualmachine'][$i];
	
				if($vm[$condition] == $value){
					$result[$resultIndex++] = $vm;
				}
			}
			return $result;
		}
	}
	
	//------------서버 기능 
	
	public function startVM(){
		$cmdArr = array(
		    "command" => "startVirtualMachine", 
		    "id" => $_POST['vmid'],
		    "apikey" => $_SESSION['apikey']
		);
		  
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $result;
	}
	
	public function stopVM(){ 
		$cmdArr = array(
				"command" => "stopVirtualMachine", 
				"id" => $_POST['vmid'],
				"apikey" => $_SESSION['apikey']
		); 
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $result;
	}
	
	public function rebootVM(){
		$cmdArr = array(
				"command" => "rebootVirtualMachine",
				"id" => $_POST['vmid'],
				"apikey" => $_SESSION['apikey']
		);
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $result;
	}
	
	public function rebootVM2($vmid){
		$cmdArr = array(
				"command" => "rebootVirtualMachine",
				"id" => $vmid,
				"apikey" => $_SESSION['apikey']
		);
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $result;
	}
	

	public function initializeOS($vmid){
		$cmdArr = array(
				"command" => "restoreVirtualMachine",
				"virtualmachineid" => $vmid,
				"apikey" => $_SESSION['apikey']
		);
	
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $result;
	}
	
	public function resetPwdVM($vmid){
		$cmdArr = array(
				"command" => "resetPasswordForVirtualMachine",
				"id" => $vmid,
				"apikey" => $_SESSION['apikey']
		);
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $result;
	}
	
	public function deleteVM($vmid){
		$cmdArr = array(
				"command" => "destroyVirtualMachine",
				"id" => $vmid,
				"expunge"=>'true',//완전한삭제
				"apikey" => $_SESSION['apikey']
		);
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $result;
	}
	
	public function updateDisplayname($vmid, $newDisplayname){
		$cmdArr = array(
				"command" => "updateVirtualMachine",
				"virtualmachineid" => $vmid,
				"displayname" => $newDisplayname,
				"apikey" => $_SESSION['apikey']
		);
		
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $result;
	} 
}