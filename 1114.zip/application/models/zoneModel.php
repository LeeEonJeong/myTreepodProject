<?php

class ZoneModel extends CI_Model {
	public function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' );
	}
	
	public function getlistZones(){
		$cmdArr = array (
				"command" => "listZones",
				"apikey" => $_SESSION ['apikey']
		);
		
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $result;
	}
	
	public function getZonename($zoneid){
		$result = $this->getlistZones();
		$count = $result['count'];
		$zones = $result['zone'];
	
		for($i=0; $i<$count; $i++){
			if($count==1){
				$zone = $zones;
			}else{
				$zone = $zones[$i];
			}
			if($zone['id'] == $zoneid){
				return $zone['name'];
			}
		}
	} 
}