<?php
class AccountModel extends CI_Model {
	public function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' ); 
	}
	
	public function getlistAccounts() { 
		$cmdArr = array(
				"command" => "listAccounts", 
				"apikey" => $_SESSION ['apikey']
		);
		
		$result = $this->callApiModel->callCommand(CallApiModel::URI, $cmdArr, $_SESSION['secretkey']); 
		return $result;
	} 
}