<?php
class AddressModel extends CI_Model {
	public function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' );
	}
	
	public function associateIpAddress($zoneid, $usageplantype){
		$cmdArr = array (
				"command" => "associateIpAddress",
				"zoneid" => $zoneid,
				"usageplantype" => $usageplantype,
				"apikey" => $_SESSION ['apikey']
		);
	
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $result;
	}
	
	public function disassociateIpAddress($id){
		$cmdArr = array (
				"command" => "disassociateIpAddress",
				"id" => $id,
				"apikey" => $_SESSION ['apikey']
		);
	
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $result;
	}
	
	public function getlistPublicIpAddresses() {
		$cmdArr = array (
				"command" => "listPublicIpAddresses",
				"apikey" => $_SESSION ['apikey']
		);
	
		$publicIpAddreses = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $publicIpAddreses;
	}
	
	public function getAddIpCount(){
		$addIpCount=0;
		$result = $this->getlistPublicIpAddresses();
		$count = $result['count'];
		$ips = $result['publicipaddress'];
	
		for($i=0; $i<$count; $i++){
			if($count==0){
				$ip = $ips;
			}else{
				$ip = $ips[$i];
			}
				
			if($ip['issourcenat'] == 'false'){
				$addIpCount++;
			}
		}
		return $addIpCount;
	}
	
	public function getPublicIpInfo() { //보류
		$cmdArr = array (
				"command" => "listPublicIpAddresses",
				"id" => $_POST['publicip'],
				"apikey" => $_SESSION ['apikey']
		);
	
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
			
		if($result['count'] != 1){ } //error 정보 무조건 하나일거아냐....아닌가 나중에 바뀌나?
	
		$publicip = $result['publicipaddress'];
	
		return $publicip;
	}
	
	public function getPublicIpAddressByZoneId($zoneid){
		$cmdArr = array (
				"command" => "listPublicIpAddresses",
				"zoneid" => $zoneid,
				"apikey" => $_SESSION ['apikey']
		);
	
		$publicIpAddreses = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $publicIpAddreses;
	}	
	
	public function updateIpAddress($desc, $id){ //ipdaddress에 대한 설명추가
		$cmdArr = array (
				"command" => "updateIpAddress",
				"desc" => $desc,
				"id" => $id,
				"apikey" => $_SESSION ['apikey']
		);
	
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $result;
	}
}