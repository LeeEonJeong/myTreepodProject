<?php
 
class NetworkModel extends CI_Model {
	public function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' ); 
	}
	
	public function getlistNetworks(){
		$cmdArr = array (
				"command" => "listNetworks",
				"apikey" => $_SESSION ['apikey']
		);
		
		$networks = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
		return $networks;
	}
	
	public function getNetworksByZoneid($zoneid){
		$cmdArr = array (
				"command" => "listNetworks",
				"zoneid" => $zoneid,
				"apikey" => $_SESSION ['apikey']
		);
	
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $result;
	}
	
	public function getNASNetworkInfoByZoneid($zoneid){
		$result = $this->getNetworksByZoneid($zoneid);
	
		if($result['count'] == 1){
			$network =  $result['network'];
			$name = $network['displaytext'];
			if(strpos($name,"NAS") !== false){
				return $network;
			}
		}else{
			$networks = $result['network'];
	
			foreach($networks as $network){
				$name = $network['displaytext'];
				if(strpos($name,"NAS") !== false){
					return $network;
				}
			}
		}
	}
	
	public function getNASzoneIds(){
		$networks = $this->getlistNetworks()['network'];
		
		$zoneids = array();
		foreach($networks as $network){ 
			$name = $network['name'];
			if(strpos($name,"NAS") === 0){ 
				array_push($zoneids, $network['zoneid']);
			}
		}
		 
		return $zoneids;
	}
	
	public function getNasCIPCount(){
		$networks = $this->getlistNetworks()['network'];
		
		$count=0;
		foreach($networks as $network){
			$name = $network['name'];
			if(strpos($name,"NAS") === 0){
				$count++;
			}
		}
			
		return $count;
	} 
}