<?php

class PortforwardingModel extends CI_Model {
	function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' );
	}
	
	//전체 포트포워딩 규칙 가져오기
	public function getlistPortForwardingRules(){
		$cmdArr = array (
				"command" => "listPortForwardingRules",
				"apikey" => $_SESSION ['apikey']
		);
			
		$portforwardingRules = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
			
		return $publicIpAddreses;
	}
	
	//ipaddress에 따라서 룰 가져오기
	public function getlistPortForwardingRulesByIpAdress($ipaddressid){
		$cmdArr = array (
				"command" => "listPortForwardingRules",
				//"ipaddressid" => "465e6db6-7b44-4ea4-9ab2-b4ff6c616494",
				"ipaddressid" =>$ipaddressid,
				"apikey" => $_SESSION ['apikey']
		);
	
		$portforwardingRules = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $portforwardingRules;
	}
	
	public function createPortForwarding(){ //비동기
		if(!isset($_POST['publicendport']))
		{
			$_POST['publicendport'] = $_POST['publicport'];
		}
			
		if(!isset($_POST['privateendport']))
		{
			$_POST['privateendport'] = $_POST['privateport'];
		}
			
		$cmdArr = array (
				"command" => "createPortForwardingRule",
				"ipaddressid" => $_POST['ipaddressid'],
				"publicport" => $_POST['publicport'],//포트 포워딩 규칙의 공개 포트 범위의 시작 포트
				"publicendport" => $_POST['publicendport'],
				"virtualmachineid" => $_POST["virtualmachineid"],
				"privateport" => $_POST["privateport"],//포트 포워딩 규칙의 개인 포트 범위의 시작 포트
				"privateendport" => $_POST["privateendport"],
				"protocol" => $_POST["protocol"],
				"apikey" => $_SESSION ['apikey']
		);
		//  		$cmdArr = array (
		//  				"command" => "createPortForwardingRule",
		//  				"ipaddressid" => '465e6db6-7b44-4ea4-9ab2-b4ff6c616494',
		//  				"publicport" => '1212',//포트 포워딩 규칙의 공개 포트 범위의 시작 포트
		//  				"virtualmachineid" => '1e4f6ee2-ac63-48e4-b52d-62992714545d',
		//  				"privateport" => '1212',//포트 포워딩 규칙의 개인 포트 범위의 시작 포트
		//  				"protocol" => 'TCP',
		//  				"apikey" => $_SESSION ['apikey']
		//  		);
	
		$result = $this->callApiModel->callCommandResponseJson( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		return $result;
	}
	
	public function deletePortForwardingRule($portforwardingid){ //비동기
		$cmdArr = array (
				"command" => "deletePortForwardingRule",
				"id" =>$portforwardingid,
				"apikey" => $_SESSION ['apikey']
		);
			
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		return $result;
	}
}