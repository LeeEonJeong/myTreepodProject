<?php

class FirewallModel extends CI_Model {
	public function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' );
	}
	
	public function getlistFirewallRules() {
		$cmdArr = array (
				"command" => "listFirewallRules",
				"apikey" => $_SESSION ['apikey']
		);
	
		$publicIpAddreses = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	
		return $publicIpAddreses;
	}
	
	public function getlistFireWallInfoByIpAddress($ipaddress) {
		$cmdArr = array (
				"command" => "listFirewallRules",
				"ipaddressid" => $ipaddress,
				"apikey" => $_SESSION ['apikey']
		);
	
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
			
		if(count($result) == 1){
			//attribute드간거
			return null;
		}
		return $result;
	}
	
	public function createFirewallRule(){ //비동기
		$cmdArr = array (
				"command" => "createFirewallRule",
				"ipaddressid" => $_POST['ipaddressid'],
				"protocol" => $_POST["protocol"],
				//"cidrlist" => $_POST['cidrlist'], //Firewall에 등록할 source cidrlist ( 미기입시, 모든 IP 허용 정)
				"startport" => $_POST["startport"],
				"endport" => $_POST["endport"],
				"apikey" => $_SESSION ['apikey']
		);
			
		//  		$cmdArr = array (
		//  				"command" => "createFirewallRule",
		//  				"ipaddressid" => '4846bc8a-abfd-4c60-84d7-012d7796ab85',
		//  				"protocol" =>'TCP',
		//  				//"cidrlist" => $_POST['cidrlist'], //Firewall에 등록할 source cidrlist ( 미기입시, 모든 IP 허용 정)
		//  				"startport" => '1414',
		//  				"endport" => '1414',
		//  				"apikey" => $_SESSION ['apikey']
		//  		);
			
	
		$result = $this->callApiModel->callCommandResponseJson( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		return $result;
	}
	
	
	public function deleteFirewallRule($firewallid){//비동기
		$cmdArr = array (
				"command" => "deleteFirewallRule",
				"id" => $firewallid,
				"apikey" => $_SESSION ['apikey']
		);
	
		$result = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
	}
}