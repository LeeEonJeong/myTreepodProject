<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class AsyncProcess extends MY_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('asyncProcessModel');
		}
		
// 		function index(){
// 			echo '비동기처리 controller의 index 함수입니다.';
// 		}
		
		public function queryAsyncJobResult($jobid){
			$this->_require_login('/');
			$result = $this->asyncProcessModel->queryAsyncJobResult($jobid); 
			print(json_encode($result));
		}
		
		public function queryAsyncJobResult2($jobid){ //비동기처리
			$this->_require_login('/');
			$result = $this->asyncProcessModel->queryAsyncJobResult2($jobid);
			print(json_encode($result));
		}
		
		//test용
		function getSession(){
			$this->_myprint($_SESSION);
		}
		//test용
		function destroySession(){
			$this->session->sess_destroy(); //session_destroy();
		}
		
		public function setSessionJobids($jobid,$jobresultname,$jobresultmsg){ 
				$newjobid = array(
						'jobid'     => $jobid,
						'jobresultname' => $jobresultname,
						'jobresultmsg' => $jobresultmsg
				);
			
				if($this->session->has_userdata('jobids')){
					$jobids = $this->session->userdata('jobids');
					if(is_array($jobids)){
						array_push($jobids,$newjobid);
						$this->session->set_userdata('jobids',$jobids);
					}else{//불려질일 없음
						$this->session->set_userdata('jobids', array($newjobid));
					}
				}else{
					$this->session->set_userdata('jobids', array($newjobid));
				}
		}
		 
		public function getSessionJobids(){  
				if($this->session->has_userdata('jobids')){ 
					$jobids =$this->session->userdata('jobids'); 
					if(is_array($jobids)){ 
						echo json_encode($jobids);
					}else{ //불려질일없음
						echo null;
					}
				}
		}
		
		public function unsetSessionJobids($jobid){
			if($this->session->has_userdata('jobids')){ 
				$jobids = $this->session->userdata('jobids');
				
				if(is_array($jobids)){
					foreach($jobids as $key => $value){ 
						if($value['jobid'] == $jobid){ 
							unset($jobids[$key]);
						}
					}
					$this->session->set_userdata('jobids',$jobids);
				}
			}
		}
		 
		public function unsetSessionValue($key){
			if($this->session->has_userdata($key)){
				$this->session->unset_userdata($key);
			}
		}
		
		public function setSessionValue($key, $value){
			$this->session->set_userdata($key, $value);
		}
		
		public function getSessionValue($key){
			if($this->session->has_userdata($key)){
				return $this->session->userdata($key);
			}else{
				return false;
			}
// 			if(isset($_SESSION[$key]))
// 				echo $_SESSION[$key];
// 			else
// 				echo 'false';
		}
	}