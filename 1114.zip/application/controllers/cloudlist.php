<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class Cloudlist extends MY_Controller{
		public function __construct()
		{
			parent::__construct();
			$this->load->model('cloudModel');
		}
		
		public function index(){
			$this->_head();
			$returnURI = '/cloudlist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
			
			$vms = $this->cloudModel->getlistVms(); 
			$vmcount = $vms['count'];
			
			$cloudlistdata = array(
					'clouds' => $vms,
					'vmcount' => $vmcount
			); 
		
			$this->load->view('./cloud/cloudlist', $cloudlistdata); 
		 	$this->load->view('./cloud/cloudManageMenu');
		 	
		 	$this->load->view('./cloud/serverInfo');  
			$this->_footer();
		}  
		 
		public function startVM(){
			$result = $this->cloudModel->startVM(); 
			print(json_encode($result));
		}
		
		public function stopVM(){
			$result = $this->cloudModel->stopVM(); 
			print(json_encode($result));
		}
		
		public function rebootVM(){
			$result = $this->cloudModel->rebootVM();
			print(json_encode($result));
		}
		
		public function rebootVM2($vmid){
			$result = $this->cloudModel->rebootVM2($vmid);
			print(json_encode($result));
		}
		
		 
		public function getVMsByZoneId($zoneid){
			$vms = $this->cloudModel->searchVMsByZoneid($zoneid);			
			print(json_encode($vms));
		} 
		
		private function searchVMs($zoneid, $searchword){
			if($zoneid == 'all'){
				$listVMs = $this->cloudModel->getlistVMs();
			}else{
				$listVMs = $this->cloudModel->searchVMsByZoneid($zoneid);
			}
			$result = array();
				
			$count = $listVMs['count'];
			$resultcount=0;
				
			if($count == 0 || !isset($count)){
				
			}else{
				$vms = $listVMs["virtualmachine"];
			 
				for($i=0; $i<$count; $i++){
					if($count == 1){
						$vm = $vms;
					}else{
						$vm = $vms[$i];
					}
					$isInclude = strpos($vm['displayname'], $searchword);
					 	
					//if($isInclude >= 0 && gettype($isInclude) == 'integer'){
					if($isInclude !== false){
						array_push($result,$vm);
						$resultcount++;
					}
				}
			}
			
			if($resultcount == 1){
				return array('virtualmachine' => $result[0], 'count' => $resultcount);
			}else{
				return array('virtualmachine' => $result, 'count' => $resultcount);
			}
		}
		
		public function showSearchResult($zoneid, $searchword){
			$this->_head();
			$returnURI = '/cloudlist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
				
			$vms = $this->searchVMs($zoneid,$searchword); 

			$cloudlistdata = array(
					'clouds' => $vms,
					'vmcount' => $vms['count']
			);
			
			$this->load->view('./cloud/cloudlist', $cloudlistdata);
			$this->load->view('./cloud/cloudManageMenu');
			$this->load->view('./cloud/serverInfo');
			$this->_footer();
		}
		
		public function showSearchResultByZoneId($zoneid){
			$this->_head();
			$returnURI = '/cloudlist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
			
			$vms = $this->cloudModel->searchVMsByZoneid($zoneid);
			$vmcount = $vms['count'];
				
			$cloudlistdata = array(
					'clouds' => $vms,
					'vmcount' => $vmcount
			);
			
			$this->load->view('./cloud/cloudlist', $cloudlistdata);
			$this->load->view('./cloud/cloudManageMenu');
			 
			$this->load->view('./cloud/serverInfo');
			$this->_footer();
		}
		 
		public function searchVM($vmid){
			$result = $this->cloudModel->searchVM($vmid);
			print(json_encode($result));
		} 
		
		public function initializeOS($vmid){
			$result = $this->cloudModel->initializeOS($vmid);
			print(json_encode($result));
		}
		
		public function resetPwdVM($vmid){
			$result = $this->cloudModel->resetPwdVM($vmid);
			print(json_encode($result));
		}
		
		public function deleteVM($vmid){
			$result = $this->cloudModel->deleteVM($vmid);
			print(json_encode($result));
		}
		
		public function updateDisplayname($vmid){ //동기화아님
			$result = $this->cloudModel->updateDisplayname($vmid, $newDisplayname);
			print(json_encode($result));
		} 
		
		public function getlistVMs(){
			$result = $this->cloudModel->getlistVMs();
			print(json_encode($result));
		} 
		 
		
		public function getVMsForNAS(){
			$vms = $this->cloudModel->getVMsForNAS();
			
			//존에 해당하는 cip id를 넣게위해서
			$this->load->model('networkModel');
			$index = 0;
			foreach($vms as $vm){
				$zoneid = $vm['zoneid'];
				$networkinfo = $this->networkModel->getNASNetworkInfoByZoneid($zoneid);
				$zonecipid = $networkinfo['id'];
				$vms[$index]['zonecipid'] = $zonecipid;
				$index++;
			}
			
			print(json_encode($vms));
		}  
	}