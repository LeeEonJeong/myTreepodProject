<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class Networklist extends MY_Controller{
		public function __construct()
		{
			parent::__construct();
			$this->load->model('addressModel');
			$this->load->model('networkModel');
			$this->load->model('firewallModel');
			$this->load->model('portforwardingModel');
			$this->load->model('zoneModel');
		}
		
		public function index(){
			$this->_head();
			$returnURI = '/networklist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
			
			$publicIps = $this->addressModel->getlistPublicIpAddresses();
		  
			$publicIpCount = $publicIps['count'];
			 
			$networklistdata = array(
					'publicIps' => $publicIps,
					'publicIpCount' => $publicIpCount
			); 
		
			$this->load->view('./network/networklist', $networklistdata); 
		 	$this->load->view('./network/networkManageMenu');
		    $this->load->view('./network/networkInfo');
			$this->_footer();
		} 
		
		public function showSearchResult($zoneid){
			$this->_head();
			$returnURI = '/networklist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
		
			$publicIps = $this->addressModel->getPublicIpAddressByZoneId($zoneid);
		
			$publicIpCount = $publicIps['count'];
		
			$networklistdata = array(
					'publicIps' => $publicIps,
					'publicIpCount' => $publicIpCount
			);
		
			$this->load->view('./network/networklist', $networklistdata);
			$this->load->view('./network/networkManageMenu');
			$this->load->view('./network/networkInfo');
			$this->_footer();
		}
		//----존----------------------------------------
		public function getlistZones(){
			$result = $this->zoneModel->getlistZones();
			print(json_encode($result));
		}
		
		public function getZonename($zoneid){
			$result = $this->zoneModel->getZonename($zoneid);
			print(json_encode($result));
		}
			
		
		//----네트워크----------------------------------------
		public function getNetworksByZoneid($zoneid){
			$result = $this->networkModel->getNetworksByZoneid($zoneid);
			print(json_encode($result));
		}
			
		public function getNASNetworkInfoByZoneid($zoneid){
			$result = $this->networkModel->getNASNetworkInfoByZoneid($zoneid);
			print(json_encode($result));
		}
		
		public function getlistNetworks(){
			$result = $this->networkModel->getlistNetworks();
			print(json_encode($result));
		}
		
		public function getNASzoneIds(){
			$result = $this->networkModel->getNASzoneIds();
			print(json_encode($result));
		}
		
		//-------어드레스-------------------		
		public function associateIpAddress($zoneid, $usageplantype){//비동기
			$result = $this->addressModel->associateIpAddress($zoneid, $usageplantype); 
			print(json_encode($result));
		}
		
		public function disassociateIpAddress($id){
			$publicip = $this->addressModel->disassociateIpAddress($id); 
			print(json_encode($publicip));
		}
		
		public function getlistPublicIpAddresses(){
			$publicips = $this->addressModel->getlistPublicIpAddresses();
			print(json_encode($publicips));
		}		
		
		public function getPublicIpInfo(){
			$publicip = $this->addressModel->getPublicIpInfo(); 
			print(json_encode($publicip));
		}
		
		public function updateIpAddress($desc, $id){ //ipdaddress에 대한 설명추가
			$publicip = $this->addressModel->updateIpAddress($desc, $id);
			print(json_encode($publicip));
		}
		
		public function getPublicIpAddressByZoneId($zoneid){
			$firewallRules = $this->addressModel->getPublicIpAddressByZoneId($zoneid);
			print(json_encode($firewallRules));
		}
		
		//-------포트포워딩--------------------
		public function createPortForwarding(){
			$result = $this->portforwardingModel->createPortForwarding();
			print  $result;
		}
		
		public function getlistPortForwardingRulesByIpAdress($ipaddressid){
			$portforwardingRules = $this->portforwardingModel->getlistPortForwardingRulesByIpAdress($ipaddressid);
			print(json_encode($portforwardingRules));
		}
		
		public function deletePortForwardingRule($portforwardingid){
			$result = $this->portforwardingModel->deletePortForwardingRule($portforwardingid);
			print(json_encode($result));
		}
		
		//-------방화벽------------------
		public function getlistFireWallInfoByIpAddress($ipaddress){
			$firewallRules = $this->firewallModel->getlistFireWallInfoByIpAddress($ipaddress);
			print(json_encode($firewallRules));
		}
		
		public function createFirewallRule(){
			$result = $this->firewallModel->createFirewallRule();
			print($result);
		}
		
		public function deleteFirewallRule($firewallid){
			$result = $this->firewallModel->deleteFirewallRule($firewallid);
			print(json_encode($result));
		}
	}