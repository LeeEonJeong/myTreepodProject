<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	 
	class CifsAccount extends MY_Controller{
		public function __construct()
		{
			parent::__construct(); 
			$this->load->model('cifsAccountModel');
		}
		
		public function getWorkGroupName(){
			echo $this->cifsAccountModel->getWorkGroupName();
		}
		
		public function listCifsAccounts(){//CIFS 아이디의 목록을 조회한다.
			$result = $this->cifsAccountModel->listCifsAccounts();
			echo $result;
			//{"listcifsaccountsresponse":{"status":"success","totalcount":0,"response":[]}}
			//{"listcifsaccountsresponse":{"status":"success","totalcount":2,"response":["adfasdf","testtest"]}}
		}
		
		public function addCifsAccount(){//CIFS 볼륨 접근에 필요한 ID를 생성한다. (최대 10개까지 생성 가능함)
			$result = $this->cifsAccountModel->addCifsAccount(); 
			echo json_encode($result); 
			//{"errorcode":"530","errortext":"CIFS password format is invalid","status":"error"}
			// {"response":{"cifsid":"asdfasdf"},"status":"success"}
		} 
		
		public function deleteCifsAccount($cifsId){//CIFS 아이디를 삭제한다.
			$result = $this->cifsAccountModel->deleteCifsAccount($cifsId);
			echo json_encode($result);
			//{"errorcode":"530","errortext":"Insert to CIFS ID","status":"error"}
			//{"response":null,"status":"success"}
		}
		
		public function listAccountForNas(){//NAS 서비스 이용을 위한 내부 계정의정보를 조회한다.
			$result = $this->cifsAccountModel->listAccountForNas();
			echo json_encode($result);
			//{"response":{"cifsid":"asdfasdf","cifspwd":null,"cifsworkgroup":"EONJEONGGROUP","networkcount":"1","volumecount":"3"},"status":"success"}
		} 
		 
		public function updateAccountForNas($cifsworkgroup){ //NAS 서비스 이용을 위한 내부 계정의 cifs 인증정보를 갱신한다. -> workgroup변경시에 사용
			$result = $this->cifsAccountModel->updateAccountForNas($cifsworkgroup);
			print json_encode($result);
			//{"response":{"cifsid":"asdfasdf","cifsworkgroup":"TESTTEST2","networkcount":"1","volumecount":"3"},"status":"success"}
		} 
		
		public function updateCifsAccount(){//CIFS 아이디의 비밀번호를 변경한다.
			//특수문자때문에 POST로
			$result = $this->cifsAccountModel->updateCifsAccount();
			print json_encode($result);
		}
	}
		