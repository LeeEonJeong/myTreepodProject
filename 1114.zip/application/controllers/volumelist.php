<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Volumelist extends MY_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('volumeModel');
		}
		
		public function index(){
			$this->_head();
			$returnURI = '/networklist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
			
			$volumes = $this->volumeModel->getlistVolumes();
		  
			$volumeCount = $volumes['count'];
			 
			$volumelistdata = array(
					'volumes' => $volumes,
					'volumeCount' => $volumeCount
			); 
		
			$this->load->view('./volume/volumelist', $volumelistdata);
			$this->load->view('./volume/volumeManageMenu');
		    $this->load->view('./volume/volumeInfo');
			$this->_footer();
		}
		
		private function searchVolumes($zoneid, $searchword){
			if($zoneid == 'all'){
				$listVolumes = $this->volumeModel->getlistVolumes();
			}else{
				$listVolumes = $this->volumeModel->getVolumesByZoneid($zoneid);
			}
			
			$result = array();
			 
			$volumeCount = $listVolumes['count'];
			$resultcount=0;
			
			if($volumeCount == 0 || !isset($volumeCount)){
			
			}else{
				$volumes = $listVolumes["volume"]; 
					
				for($i=0; $i<$volumeCount; $i++){
					if($volumeCount == 1){
						$volume = $volumes;
					}else{
						$volume = $volumes[$i];
					}
					
					$isInclude = strpos($volume['name'], $searchword);
					if($isInclude !== false){
						array_push($result,$volume);
						$resultcount++;
					}
				}
			}
			if($resultcount == 1){
				return array('volume' => $result[0], 'count' => $resultcount);
			}else{
				return array('volume' => $result, 'count' => $resultcount);
			}
		}
		
		public function showSearchResult($zoneid, $searchword){
			$this->_head();
			$returnURI = '/volumelist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
		
			$volumes = $this->searchVolumes($zoneid,$searchword); //무조건 array생성해서들어와
				
			$volumelistdata = array(
					'volumes' => $volumes,
					'volumeCount' => $volumes['count']
			);
			
			$this->load->view('./volume/volumelist', $volumelistdata);
			$this->load->view('./volume/volumeManageMenu');
			$this->load->view('./volume/volumeInfo');
			$this->_footer(); 
		}
		
		public function showSearchResultByZoneId($zoneid){
			$this->_head();
			$returnURI = '/volumelist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
			 
			$result = $this->volumeModel->getVolumesByZoneid($zoneid);
			
			$volumelistdata = array(
					'volumes' => $result,
					'volumeCount' => $result['count']
			);
			
			$this->load->view('./volume/volumelist', $volumelistdata);
			$this->load->view('./volume/volumeManageMenu');
			$this->load->view('./volume/volumeInfo');
			$this->_footer(); ;
		}
		
		public function getlistVolumes(){
			$result =  $this->volumeModel->getlistVolumes();
			print( json_encode($result));
		}
		
		public function searchVolume($volumeid){
			$result = $this->volumeModel->searchVolume($volumeid);
			
			print(json_encode($result));
		} 
		
		public function getVolumes($virtualmachineid){
			$result = $this->volumeModel->getVolumes($virtualmachineid); 
			print(json_encode($result));
		}
		
		public function attachVolume($id, $virtualmachineid){
			$result = $this->volumeModel->attachVolume($id, $virtualmachineid); 
			print(json_encode($result));
		}
		
		public function detachVolume($id){
			$result = $this->volumeModel->detachVolume($id); 
			print(json_encode($result));
		}
		
		public function deleteVolume($id){
			$result = $this->volumeModel->deleteVolume($id); 
			print(json_encode($result));
		}
	}