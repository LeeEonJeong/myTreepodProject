 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class OrderCloud extends MY_Controller{
		public function __construct() {
			parent::__construct();
			$this->load->model('orderCloudModel');
		}
		
		public function index() {
			$this->_head();
			$returnURI = '/cloudlist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
			 
			$this->load->view ('/cloud/orderCloud');
			$this->_footer ();
		} 
		
		public function checkVirtualMachineName($checkname) {
			$result = $this->orderCloudModel->checkVirtualMachineName($checkname);
			echo $result['Success'];
		}
		 
		public function getPackagesByZoneid($zoneid){
			$packages =  $this->orderCloudModel->getPackagesByZoneid($zoneid);
			echo json_encode($packages);
		}
		 
		public function getOSlist($zoneid, $package){
			$oslist = $this->orderCloudModel->getOSlist($zoneid, $package);
			echo json_encode($oslist);
		}
		
		public function getServiceOfferinglist($zoneid, $package, $osid){
			$serviceofferinglist = $this->orderCloudModel->getServiceOfferinglist($zoneid, $package, $osid);
			echo json_encode($serviceofferinglist);
		}
		
		public function getDiskOfferinglist($zoneid, $package, $osid, $serviceid){
			$diskofferinglist = $this->orderCloudModel->getDiskOfferinglist($zoneid, $package, $osid, $serviceid);
			echo json_encode($diskofferinglist);
		}
		 
		public function orderVM(){  
			$result = $this->orderCloudModel->orderVM();
			echo json_encode($result);
		}
	}