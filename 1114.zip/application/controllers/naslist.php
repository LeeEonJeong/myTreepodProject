<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	 
	class Naslist extends MY_Controller{
		public function __construct()
		{
			parent::__construct();
			$this->load->model('nasModel');
		}
		
		public function index(){
			$this->_head();
			$returnURI = '/naslist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
			
			$volumes = $this->getRunningVolumes();
			$nasCount = $volumes['count'];
			
			if($nasCount == 0){
				echo "<script>alert('NAS가 없습니다.');</script>";
				$naslistdata = array(
					'nasVolumes' => array(),
					'nasvolumeCount' => $nasCount
				);
			}else{
				//$nasvolumes = $this->getRunningVolumes()['response']; 
				$nasvolumes = $volumes['response'];
				$this->setZoneName($nasvolumes);
				 
				$naslistdata = array(
						'nasVolumes' => $nasvolumes,
						'nasvolumeCount' => $nasCount
				);
			}
		
			$this->load->view('./nas/naslist', $naslistdata); 
		 	$this->load->view('./nas/nasManageMenu');
		    $this->load->view('./nas/nasInfo');
			$this->_footer();
		}
		
		public function showSearchResult($zoneid){
			$this->_head();
			$returnURI = '/naslist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
		
			$volumes = $this->nasModel->getVolumesByZoneid($zoneid);
			$nasCount = $volumes['count'];
			
			if($nasCount == 0){
				echo "<script>alert('검색결과(NAS)가 없습니다.');</script>";
				$naslistdata = array(
						'nasVolumes' => array(),
						'nasvolumeCount' => $nasCount
				);
			}else{ 
				$nasvolumes = $volumes['response'];
				$this->setZoneName($nasvolumes);
					
				$naslistdata = array(
						'nasVolumes' => $nasvolumes,
						'nasvolumeCount' => $nasCount
				);
			} 
			$this->load->view('./nas/naslist', $naslistdata);
			$this->load->view('./nas/nasManageMenu');
			$this->load->view('./nas/nasInfo');
			$this->_footer();
		}
		
		private function setZoneName(&$nasvolumes){
			$this->load->model('zoneModel');
			
			for($i=0; $i<count($nasvolume); $i++){
				if($nasCount == 1){
					$nasVolume = $nasvolumes;
				}else{
					$nasVolume = $nasvolumes[$i];
				}
					
				$zonename = $this->zoneModel->getZonename($nasVolume['zoneid']);
				if($nasCount == 1){
					$nasvolumes['zonename'] = $zonename;
				}else{
					$nasvolumes[$i]['zonename'] = $zonename;
				}
			}			
		}
		
		private function getRunningVolumes(){
			return $this->nasModel->getVolumes('status', 'online');
		}
		
		public function getlistVolumes(){
			$result = $this->nasModel->getlistVolumes();
			print(json_encode($result));
		}
		
		public function orderNas(){
			$this->_head();
			$this->load->view('./nas/orderNas');
			$this->_footer();
		} 
		
		public function deleteVolume($volumeid) {
			$result = $this->nasModel->deleteVolume($volumeid);
			print(json_encode($result));
		}
		  
		public function addNicToVirtualMachine($networkid, $virtualmachineid){//비동기
			$result = $this->nasModel->addNicToVirtualMachine($networkid, $virtualmachineid);
			print(json_encode($result));
		}
		 
		public function removeNicFromVirtualMachine($nicid, $virtualmachineid){//비동기
			$result = $this->nasModel->removeNicFromVirtualMachine($nicid, $virtualmachineid);
			print(json_encode($result));
		}
		
		public function searchNas($nasid){
			$result = $this->nasModel->getVolumes('id', $nasid);
			print(json_encode($result));
		}
	}