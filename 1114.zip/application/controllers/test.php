<?php
class Test extends MY_Controller{
	function __construct(){
		parent::__construct();
	}
	
	function test(){
// 		if(!$this->session->userdata('is_login')){
// 			echo site_url('/test/test');
// 			redirect('/auth/login?returnURL='.rawurlencode(site_url('/test/test')));
// 			//redirect('/auth/login?returnURL='.rawurlencode('http://localhost/project1/index.php/test/test'));
// 		}
		$this->load->view('head');
		$this->load->view('test');
		
	}
	
	function test11(){
		$mystring = 'abc';
		$findme   = 'bcd';
		$pos = strpos($mystring, $findme);
		
		// Note our use of ===.  Simply == would not work as expected
		// because the position of 'a' was the 0th (first) character.
		
		echo var_dump($pos);
		if ($pos === false) {
			echo "The string '$findme' was not found in the string '$mystring'";
		} else {
			echo "The string '$findme' was found in the string '$mystring'";
			echo " and exists at position $pos";
		}
	}
	
	function test2(){ 
		$test = null;
		$result =  json_encode($test); 
	
		//echo gettype($result);//null이면  string으로찍어
		
		$test2 = array();
		//echo json_encode($test2); //[]
		
		$test3 = array('test');
		echo json_encode($test3);//["test"]
		
		//$test4 = [{"jobid":"startVM","jobresultname":"12345","jobresultMsg":"virtualmachine"}]
		  
// 		echo '[{"jobid":"startVM","jobresultname":"12345","jobresultMsg":"virtualmachine"}]'; 
	}
	
	function test3(){
		$arrayObject = array(
			'lee' => 'eonjeong',
			'jeon' => 'gahye'
		);
		
		echo json_encode($arrayObject); //{"lee":"eonjeong","jeon":"gahye"}  
		echo json_encode(array('test', 'test2')); //["test","test2"]
		echo json_encode (array ('test', 'test2'=>'test2value')); //{"0":"test","test2":"test2value"}
		echo json_encode (array ('test', 'test2'=>'test2value', array ('test', 'test2'=>'test2value')));//{"0":"test","test2":"test2value","1":{"0":"test","test2":"test2value"}}
	}
	
	function test4(){
		$this->session->set_userdata('testkey', array('test','test2','test3',array('test4','test5'))); //Session의 key는 숫자가 아니라 value로 주자
		
		$this->session->set_userdata('eonjeong'); 
		
		$this->_myprint($this->session->get_userdata());
	}
	
	function test5(){
		echo json_encode(array());
	}
	
// 	function test(){
// 		$this->load->model('networksModel');
// 		echo $this->networksModel->getAddIpCount();
		
// 		$this->load->model('networksModel');
// 		echo $this->networksModel->getNasCIPCount();
		
// 		$this->load->model('volumesModel');
// 		echo $this->volumesModel->getAddVolumeCount();
// 	}
	
// 	function test(){
// // 		$this->load->view('js/test.js');
// 		echo strpos('test','e');
// 		echo '<br>';
// 		echo gettype(strpos('test','qwe'));
// 		echo '<br>';
// 		echo strpos('test','test');
// 		echo '<br>';
// 		echo strpos('test','s');
// 		echo '<br>';
		
// 		$result = strpos('test','qwe');
// 		if($result){ //false
// 			echo 'test';
// 		}else{
// 			echo 'test2';
// 		}
// 		//$this->load->view('test');
// 	}
	
// 	function test(){
// 		$this->load->model('callApiModel');
// 		$cmdArr = array (
// 				"command" => "addVolume",
// 				"apikey" => $_SESSION ['apikey'] 
// 		);
		
// 		$vms = $this->callApiModel->callCommandReponseJson( CallApiModel::NASURI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		
// 		//var_dump($vms);
// 	}
}