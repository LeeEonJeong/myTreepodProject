 <script>
$(
		function(){ 
			$('#connectciporderbtn').click(
					function(){
						selectconnectvm = $("input:checkbox[name='selectconnectvm']:checked");
						$(this).parents().find('.modal').modal('hide');
						if(selectconnectvm.length == 0){
							return;
						}
						selectconnectvm.each(function(){ 
							vmidandzonecipid = this.value;
							temp = vmidandzonecipid.split('/');
							vmid = temp[0];
							zonecipid = temp[1];				
							$.ajax({
								type:'GET',
								url:'/naslist/addNicToVirtualMachine/'+zonecipid+'/'+vmid,
								dataType: 'json',
								success : function(data){
// 									showObj(data);
									 if(data.jobid){
									 	async(data.jobid,'CONNECT CIP');
									 }else{
										setModalMsg('CONNECT CIP 실패').modal();
									 } 
								},
								error : function( ){  
									 setModalMsg('CONNECT CIP 실패(error)').modal();
								}
							}); 
						}); //체크된 것들 모두 connect 실행 
					}
			); 
});  
</script>

<!-- connect cip modal  -->
<div class="modal fade" id='connectcipModal' role="dialog">
  <div class="modal-dialog">
	  <div class="modal-content">
	      <div class="modal-header"> 
	        <h4 class="modal-title">NAS cip 연결</h4>
	      </div>
	      <div class="modal-body"> 
	        <table id="connectcipserverlist_table"> 
			   		<thead style='background-color:#f4f4f4'>
				   		<tr>
				   			<th></th>
				   			<th>Zone</th>
				   			<th>서버명</th>
				   			<th>운영체제</th>
				   			<th>스펙</th>
				   			<th>상태</th>
				   		</tr>
			   		</thead>
			   		<tbody>
			   		</tbody>
			 	</table>
			 	<br>
			 	<p style='color:red'>* 정지된 서버는 연결이 불가능합니다.</p>
	      </div>	
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	         <input type="button" class="btn btn-primary" id="connectciporderbtn"class="btn" value="확인"/>
	      </div>
	    </div> 
	</div>
</div>