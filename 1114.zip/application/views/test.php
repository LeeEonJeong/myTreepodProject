 </div>
 </div>
 
 <script>
$(
	function(){
		 $.ajax({
				type:'GET',
				url:"/test/test5",
				dataType:"json",
				success : function(data){
					alert(data);
					alert(typeof(data));
					alert(data.length);
				},
				error : function(){ 
				}
		 }); 
	}
);
 </script>
 <div class='container-fluid'>
 <div class='row-fluid'>
 	<div class='span4' style='border:1px solid red'>
 		span4
 	</div>
 	<div class='span8'style='border:1px solid blue'>
 		span8
 		 <div class="row-fluid">
          <div class="span6" style='border:1px solid green'>Fluid 6</div>
          <div class="span6" style='border:1px solid green'>Fluid 6</div>
        </div>
 	</div>
 </div>
 </div>
</body>
</html>