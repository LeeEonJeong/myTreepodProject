<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class AsyncProcess extends MY_Controller{
		function __construct()
		{
			parent::__construct();
			$this->load->model('asyncProcessModel');
		}
		
		function index(){
			echo '비동기처리 controller의 index 함수입니다.';
		}
		
		function queryAsyncJobResult($jobid){
			$this->_require_login('/');
			$result = $this->asyncProcessModel->queryAsyncJobResult($jobid); 
			print(json_encode($result));
		}
		
		function queryAsyncJobResult2($jobid){
			$this->_require_login('/');
			$result = $this->asyncProcessModel->queryAsyncJobResult2($jobid);
			print(json_encode($result));
		}
		
		function setSessionJobid($jobid){
			$_SESSION['jobid'] = $jobid;
		}
		
		function getSessionJobid(){
			if(isset($_SESSION['jobid']))
				echo $_SESSION['jobid'];
			else
				echo 'noexist';
		}
		
		function setSeesionJobids($jobname,$jobid,$jobresultname){
				$newjobid = array(
						'jobname'  => $jobname,
						'jobid'     => $jobid,
						'jobresultname' => $jobresultname 
				);
			
				//echo var_dump($this->session->has_userdata('jobid'));
			
				$tempjobids=$this->session->get_userdata('jobids');
				
				//echo '<hr>'.var_dump($tempjobids);
				
				if(isset($tempjobids['jobids'])){
					$jobids = $tempjobids['jobids'];
					
					//echo var_dump($jobids);
					
					if(is_array($jobids)){
						array_push($jobids,$newjobid);
						$this->session->set_userdata('jobids',$jobids);
					}else{
						$jobidArray = array();
						$this->seesion->set_userdata('jobids',$jobidArray);
					}
				}else{
					//echo 'new';
					$jobidArray = array();
					array_push($jobidArray, $newjobid);
					$this->session->set_userdata('jobids',$jobidArray);
				}
		}
		
		function getSessionJobids(){
				if($this->session->has_userdata('jobids')){
					$tempjobids=$this->session->get_userdata('jobids');//모든 seesion값들가져옴?
					
					$jobids = $tempjobids['jobids'];
					
					//echo var_dump($jobids);
					if(is_array($jobids)){
						echo json_encode($jobids);
					}else{
						echo 'noexist';
					}
				}
		}
		
		function unsetSessionJobids($jobid){
			if($this->session->has_userdata('jobids')){
				$tempjobids=$this->session->get_userdata('jobids');//모든 seesion값들가져옴?
				 
				//echo var_dump($tempjobids);
				
				$jobids = $tempjobids['jobids'];
				
				if(is_array($jobids)){  
					$count = count($jobids);
					foreach($jobids as $key => $value){
						//echo var_dump($jobids[$i]).'<hr>';
						if($value['jobid'] == $jobid){
							//echo var_dump($key);
							unset($jobids[$key]);
						}
					}
					$this->session->set_userdata('jobids',$jobids);
				}
			}
		}
		
		function unsetSessionJobid(){
			if(isset($_SESSION['jobid'])){
				unset($_SESSION["jobid"]);
			}
		}
		
		function unsetSessionValue($key){
			if(isset($_SESSION[$key])){
				unset($_SESSION[$key]);
			}
		}
		
		function setSessionValue($key, $value){
			$_SESSION[$key] = $value;
		}
		
		function getSessionValue($key){
			if(isset($_SESSION[$key]))
				echo $_SESSION[$key];
			else
				echo 'false';
		}
	}