<div class="span2"> 
	 <ul class="nav nav-list" id="volumeMangeMenu">
		  <li class="nav-header">디스크정보</li> 
		  <li id="volumeinfoMenu"><a href="#">볼륨상세보기</a></li>
	</ul> 
 </div>
