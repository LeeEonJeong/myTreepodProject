 </div>
 </div>
 <div class='container-fluid'>
 <div class='row-fluid'>
 	<div class='span4' style='border:1px solid red'>
 		span4
 	</div>
 	<div class='span8'style='border:1px solid blue'>
 		span8
 		 <div class="row-fluid">
          <div class="span6" style='border:1px solid green'>Fluid 6</div>
          <div class="span6" style='border:1px solid green'>Fluid 6</div>
        </div>
 	</div>
 </div>
 </div>
</body>
</html>