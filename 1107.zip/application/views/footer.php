</div></div> <!-- 메뉴와 정보의 container-fluid와 row-fluid -->
</div></div><!-- 마지막 div2개는 head의 container-fluid와 row-fluid -->
<br>
<div class="container-fluid" style='background-color:#f4f4f4;'>
	 <div class="row-fluid"> 
	 	<div class="span4 offset4">
 		 <dl class="dl-horizontal">
            <dt>Made By</dt>
            <dd>Lee Eon Jeong</dd>
            <dt>Contact Information</dt>
            <dd><a href="mailto:awsed33859@naver.com">awsed33859@naver.com</a></dd>
          </dl>
		</div>
	</div>
</div>
</body>
</html>