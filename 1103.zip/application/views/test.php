 
<script>
$(
		function(){
			alert('test');
			setModalMsg('test').modal();
		}
);

</script>
 
<body> 
<form method='post' action='/cifsAccount/addCifsAccount'>
 
<input type="text" name="cifsid"  />
<input type="text" name="cifspwd" />
<input type='submit'/>
<img src='/test.png'/>
</form>
</body>
</html>