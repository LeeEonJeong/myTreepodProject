<script>
$(
		function(){
			async('test','test');
		}
);

</script>
 
<body> 
 test
</body>
</html>