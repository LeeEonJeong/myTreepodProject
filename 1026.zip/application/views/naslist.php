<?php include 'connectCIPModal.php'?>
<?php include 'disconnectCIPModal.php'?>

<span style="display:none" id="where" >nasvolume</span>

<!--  NAS볼륨 검색하기 -->
	<div class="container-fluid">
		<div class="row-fluid" >
			<div class="span7"  >
				<h5>NAS볼륨 검색하기</h5>
				<form>
					<div class="custom-search-input">
						<select id='zonename'>
			   					<option value='all'>존을 선택하세요.</option>
								<option value="eceb5d65-6571-4696-875f-5a17949f3317">KOR-Central A</option>
								<option value="9845bd17-d438-4bde-816d-1b12f37d5080">KOR-Central B</option>
								<option value="dfd6f03d-dae5-458e-a2ea-cb6a55d0d994">KOR-HA</option>
								<option value="95e2f517-d64a-4866-8585-5177c256f7c7">KOR-Seoul M</option>
								<option value="3e8ce14a-09f1-416c-83b3-df95af9d6308">JPN</option>
								<option value="b7eb18c8-876d-4dc6-9215-3bd455bb05be">US-West</option>
						</select>
						<input type="text" class="input-medium search-query" placeholder="검색할  NAS볼륨명을  입력해 주세요." />
						<span class="input-group-btn">
							<button type="button">
								<i class="icon-search fa-10x"></i> 검색
							</button>
						</span> 
					</div> 
				</form>
			</div>
			<div class="span5" >
			<div class="nav pull-right">
				<br><br> 
					<a class="btn btn-primary" href="naslist/orderNas">NAS생성</a> 
			</div> 
			</div>
		</div>
	</div>

<script>
$( 
//-----------------------------
		function (){
			function setModalMsg(msg){ 
				 $('#msgModal #msg').empty();
				 $('#msgModal #msg').html(msg);
				 return $('#msgModal');
			} 
			
			function showLoadingModal(){
				$('#loadingModal').modal({backdrop:"static", keyboard:false}); 
			}

			function async(jobid, processname){
				 showLoadingModal();
				 $.ajax({
					 type:'GET',
					 url:'/asyncProcess/queryAsyncJobResult/'+jobid,
					 dataType:'json',
					 success : function(data){  
						 if(data === 'error'){ 
							 setModalMsg(processname + '실행이 실패하였습니다..(aync)').modal();
						 }
					 },
					 error:function(){ 
						 setModalMsg(processname + '실행이 실패하였습니다..(aync)').modal(); 
					 },
					 complete:function(){
						 $('#loadingModal').modal('hide');
						 window.location.reload();
					 }
				 }); 
			} 
			
			$('#nasdiv').hide();
			$('#connectservermanagediv').hide();
			$('#nasdiv').prev('span').text('NAS볼륨을 선택해 주세요.');
 
			$('#nasvolumelist_table tr').click(
					function(){
						$('#nasdiv').prev('span').hide();
						$('#nasdiv').show();
						$('#connectservermanagediv').hide();
						$('#nasvolumeinfodiv').prev('span').remove();
						$('#nasvolumeinfoMenu').addClass('active');
						$('#connectserverManageMenu').removeClass('active');
						 
						
						$('#selectnasvolume').html($(this).find('#nasvolumename').text());

						nasvolumeid = $(this).find('span:first').text();

						$('#nasselectvolumeid').html(nasvolumeid);
 
						$.ajax({
							type:"GET",
	 	 					url:"/naslist/searchNas/"+nasvolumeid,
	 	 					dataType:'json',
	 	 					success:function(data){
	 	 	 					nas = data.response;
	 	 	 					
	 	 	 					$('#name').html(nas.name);
	 	 	 					$('#nasvolumeinfo_table #nasId').html(nas.id);
	 	 	 					$('#nasvolumeinfo_table #name').html(nas.name);
	 	 	 					$('#nasvolumeinfo_table #volumetype').html(nas.volumetype);
	 	 	 					$('#nasvolumeinfo_table #totalsize').html(nas.totalsize / 1073741824);
	 	 	 					$('#nasvolumeinfo_table #created').html(nas.created);
	 	 	 					$('#nasvolumeinfo_table #usageplantype').html(nas.usageplantype);
	 	 	 					$('#nasvolumeinfo_table #filesused').html(nas.filesused);
	 	 	 					$('#nasvolumeinfo_table #filestotal').html(nas.filestotal);
	 	 	 					$('#nasvolumeinfo_table #ipslashpath').html(nas.ip+"/"+nas.path);
	 	 	 					  
	 	 					},
	 	 					error:function(){
	 	 	 					alert('수행실패');
	 	 					}
						});
					}
			);
			 

			$('#deletenasvolumebtn').click(
					function(){
						nasvolumeid = $('#nasId').html();

						$.ajax({
							type:'GET',
							url:'/naslist/deleteVolume/'+nasvolumeid,
							dataType: 'json',
							success : function(data){ 
								 window.location.reload();
							},
							error : function( ){ 
								alert('실행실패');
							}
						}); //ajax
					}
			);

			$('#nasvolumeinfoMenu').click(
					function(){
						$('#connectserverManageMenu').removeClass('active');
						$(this).addClass('active');
						$('#connectservermanagediv').hide();
						$('#nasdiv').show();
					 
					}
			);

			$('#connectserverManageMenu').click(
					function(){
						$('#nasdiv').prev('span').hide();
						
						$('#nasvolumeinfoMenu').removeClass('active');
						$(this).addClass('active');
						$('#nasdiv').hide();
						$('#connectservermanagediv').show();

						$('#connectserverinfo_table tbody').empty();
						$.ajax({
							type:'GET',
							url:'/cloudlist/getVMsForNAS',
							dataType: 'json',
							success : function(data){ 
								
								for(i=0; i<data.length; i++){
								 vm = data[i];
								 if(vm.useNas){
									 use = '사용중'
								 }else{
									 use = '-'
								 }
								  
								 $('#connectserverinfo_table tbody').append($('<tr></tr>'))
								 	.append(
											 $('<td></td>').html(use),
											 $('<td></td>').html(vm.zonename),
											 $('<td></td>').html(vm.displayname),
											 $('<td></td>').html(vm.templatedisplaytext),
											 $('<td></td>').html(vm.serviceofferingname),
											 $('<td></td>').html(vm.state)
									);
								}
							},
							error : function( ){ 
								alert('실행실패');
							}
						}); //ajax
					 
					}
			);

			$('#connectcipbtn').click(
					function(){ 
						$.ajax({
							type:'GET',
							url:'/cloudlist/getVMsForNAS',
							dataType: 'json',
							success : function(data){ 
								$('#connectcipModal #connectcipserverlist_table tbody').empty();
								$count = 0; 
								for(i=0; i<data.length; i++){
									 vm = data[i]; 
									 
									 if( vm.state == 'Running' && vm.useNas == false){
										$count++;
									 	$('#connectcipModal #connectcipserverlist_table tbody').append($('<tr></tr>'))
									 	.append(
												 $('<td></td>').html("<input type='checkbox' name='selectconnectvm' value= '"+ vm.vmid + "/" + vm.zonecipid + "'/>"), 
												 $('<td></td>').html(vm.zonename),
												 $('<td></td>').html(vm.displayname),
												 $('<td></td>').html(vm.templatedisplaytext),
												 $('<td></td>').html(vm.serviceofferingname),
												 $('<td></td>').html(vm.state),
												 $('<td></td>').html('')
										);
									}
								} 
								if($count == 0){
									setModalMsg('현재 CIP에 연결할 서버가 없습니다.').modal();
								}else{ 
									$('#connectcipModal').modal();
								}
							},
							error : function( ){ 
								alert('실행실패');
							}
						}); //ajax
					}
			);

			$('#disconnectcipbtn').click(
					function(){ 
						$.ajax({
							type:'GET',
							url:'/cloudlist/getVMsForNAS',
							dataType: 'json',
							success : function(data){
								//alert(data.length);
								$('#disconnectcipModal #disconnectcpiserverlist_table tbody').empty();

								$useNasCount = 0;
								for(i=0; i<data.length; i++){
									 vm = data[i]; 
									 if(vm.useNas == true && vm.state=='Running'){
										 $useNasCount++;
									 	$('#disconnectcipModal #disconnectcpiserverlist_table tbody').append($('<tr></tr>'))
									 	.append(
												 $('<td></td>').html("<input type='checkbox' name='selectdisconnectvm' value= '"+ vm.vmid + "/" + vm.nicid + "'/>"), 
												 $('<td></td>').html(vm.zonename),
												 $('<td></td>').html(vm.displayname),
												 $('<td></td>').html(vm.templatedisplaytext),
												 $('<td></td>').html(vm.serviceofferingname),
												 $('<td></td>').html(vm.state),
												 $('<td></td>').html('')
										);
									}
								}
								if($useNasCount == 0){
									setModalMsg('현재 CIP에 연결된 서버가 없습니다.').modal();
								}else{
									$('#disconnectcipModal').modal();
								}
							},
							error : function( ){ 
								alert('실행실패');
							}
						}); //ajax
					}
			);
}
//-----------------------------			
);  
</script>
<div id='result'></div>


  <!-- 서버 연결 Modal -->
  <div class="modal fade" id="connectServerModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">서버 연결</h4>
        </div>
        <div class="modal-body"> 
        	<p>
      	  		<span id='volumename'></span> 
	          	<span id='volumeid' style='display: none'></span> 
          		스토리지에 연결할 클라우드 서버를 선택해 주세요.
       		</p>
       	</div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">취소</button>
          <button type='button' id ='connectServerModalBtn' class='btn btn-primary'>연결하기</button>
        </div>
      </div>
      
    </div>
  </div>
 
 <!-- 볼륨목록-->
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12" >
				<h5>NAS볼륨 목록 (총 <?= $nasvolumeCount?>건)</h5>
				<table class="table table-hover" id="nasvolumelist_table">
					<thead>
						<tr>
							<td></td>
							<td>zone</td>
							<td>볼륨명</td>
							<td>신청용량(GB)</td>
							<td>현재 사용량(GB)</td>
							<td>프로토콜</td>
						</tr>
					</thead>
					<tbody>
					
						<?php 
						for($i = 0; $i < $nasvolumeCount; $i ++) {
							if ($nasvolumeCount == 1) {
								$nasvolume = $nasVolumes;
							} else {
								$nasvolume = $nasVolumes[$i];
							}
							
							$totalsize = $nasvolume['totalsize'] / 1073741824;
							$usedsize = $nasvolume['usedsize'] / 1073741824;
					 
							echo "<tr><td>";
							echo "<span style='display:none' id='nasvolumeid'>" . $nasvolume ['id'] . "</span>";
							echo $i + 1;
							echo "</td><td id='zonename'>";
							echo "<span style='display:none' id='zoneid'>" . $nasvolume ['zonename'] . "</span>";
							echo $nasvolume ['zonename']; //zonename
							echo "</td><td id='nasvolumename'>";
							echo $nasvolume ['name'];
							echo "</td> <td>";
							echo $totalsize;
							echo "</td> <td>";
							echo $usedsize ; 
							echo "</td> <td>";
							echo $nasvolume['volumetype'] ; 
							echo "</td></tr>";
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

<!-- 볼륨상세 정보 -->
<div class="container-fluid">
	 <div class="row-fluid"> 