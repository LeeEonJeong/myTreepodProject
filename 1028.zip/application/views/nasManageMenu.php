<div class="span2"> 
	 <ul class="nav nav-list" id="nasvolumeMangeMenu">
		  <li class="nav-header">상세정보</li> 
		  <li id="nasvolumeinfoMenu"><a href="#">NAS볼륨상세보기</a></li>
		  <li id="connectserverManageMenu"><a href="#">연결서버관리</a></li>	
		  <li id="cifsAccountManageMenu"><a href="#">cifs계정관리</a></li>	  
	</ul> 
 </div>